// (c) The HDF Group
#ifndef H5Rprivate_H
#define H5Rprivate_H
#include "H5Rpublic.h"
#define H5R_ENCODE_VERSION 0x1
H5_DLL herr_t H5R_init(void);
#endif
