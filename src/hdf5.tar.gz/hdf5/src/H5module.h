// (c) The HDF Group
#ifndef H5module_H
#define H5module_H
#define H5_MODULE
#define H5_MY_PKG     H5
#define H5_MY_PKG_ERR H5E_LIB
#endif
