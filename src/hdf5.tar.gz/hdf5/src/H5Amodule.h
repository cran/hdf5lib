// (c) The HDF Group
#ifndef H5Amodule_H
#define H5Amodule_H
#define H5A_MODULE
#define H5_MY_PKG     H5A
#define H5_MY_PKG_ERR H5E_ATTR
#endif
