// (c) The HDF Group
#ifndef H5RSmodule_H
#define H5RSmodule_H
#define H5RS_MODULE
#define H5_MY_PKG     H5RS
#define H5_MY_PKG_ERR H5E_RS
#endif
