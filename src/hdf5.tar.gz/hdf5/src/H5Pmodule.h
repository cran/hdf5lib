// (c) The HDF Group
#ifndef H5Pmodule_H
#define H5Pmodule_H
#define H5P_MODULE
#define H5_MY_PKG     H5P
#define H5_MY_PKG_ERR H5E_PLIST
#endif
