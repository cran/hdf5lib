// (c) The HDF Group
#ifndef H5PLmodule_H
#define H5PLmodule_H
#define H5PL_MODULE
#define H5_MY_PKG     H5PL
#define H5_MY_PKG_ERR H5E_PLUGIN
#endif
