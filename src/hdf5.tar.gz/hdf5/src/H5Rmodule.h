// (c) The HDF Group
#ifndef H5Rmodule_H
#define H5Rmodule_H
#define H5R_MODULE
#define H5_MY_PKG     H5R
#define H5_MY_PKG_ERR H5E_REFERENCE
#endif
