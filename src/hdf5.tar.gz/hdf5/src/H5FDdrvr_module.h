// (c) The HDF Group
#ifndef H5FDdrvr_module_H
#define H5FDdrvr_module_H
#define H5_MY_PKG     H5FD
#define H5_MY_PKG_ERR H5E_FILE
#endif
