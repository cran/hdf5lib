// (c) The HDF Group
#ifndef H5FLmodule_H
#define H5FLmodule_H
#define H5FL_MODULE
#define H5_MY_PKG     H5FL
#define H5_MY_PKG_ERR H5E_RESOURCE
#endif
