// (c) The HDF Group
#ifndef H5MFmodule_H
#define H5MFmodule_H
#define H5MF_MODULE
#define H5_MY_PKG     H5MF
#define H5_MY_PKG_ERR H5E_RESOURCE
#endif
