// (c) The HDF Group
#ifndef H5B2module_H
#define H5B2module_H
#define H5B2_MODULE
#define H5_MY_PKG     H5B2
#define H5_MY_PKG_ERR H5E_BTREE
#endif
