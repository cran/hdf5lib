// (c) The HDF Group
#ifndef H5Dmodule_H
#define H5Dmodule_H
#define H5D_MODULE
#define H5_MY_PKG     H5D
#define H5_MY_PKG_ERR H5E_DATASET
#endif
