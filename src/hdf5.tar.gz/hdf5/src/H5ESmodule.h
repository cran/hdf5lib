// (c) The HDF Group
#ifndef H5ESmodule_H
#define H5ESmodule_H
#define H5ES_MODULE
#define H5_MY_PKG     H5ES
#define H5_MY_PKG_ERR H5E_EVENTSET
#endif
