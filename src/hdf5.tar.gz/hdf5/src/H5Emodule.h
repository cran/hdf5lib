// (c) The HDF Group
#ifndef H5Emodule_H
#define H5Emodule_H
#define H5E_MODULE
#define H5_MY_PKG     H5E
#define H5_MY_PKG_ERR H5E_ERROR
#endif
