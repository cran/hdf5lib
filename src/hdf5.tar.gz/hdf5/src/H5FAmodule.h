// (c) The HDF Group
#ifndef H5FAmodule_H
#define H5FAmodule_H
#define H5FA_MODULE
#define H5_MY_PKG     H5FA
#define H5_MY_PKG_ERR H5E_FARRAY
#endif
