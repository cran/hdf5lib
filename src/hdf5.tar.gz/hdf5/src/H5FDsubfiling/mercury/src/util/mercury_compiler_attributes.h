// (c) The HDF Group
#ifndef MERCURY_COMPILER_ATTRIBUTES_H
#define MERCURY_COMPILER_ATTRIBUTES_H
#if !defined(__has_attribute) && defined(__GNUC__) && (__GNUC__ >= 4)
#define __has_attribute(x)                          __GCC4_has_attribute_##x
#define __GCC4_has_attribute___visibility__         1
#define __GCC4_has_attribute___warn_unused_result__ 1
#define __GCC4_has_attribute___unused__             1
#define __GCC4_has_attribute___format__             1
#define __GCC4_has_attribute___fallthrough__        0
#endif
#if defined(_WIN32)
#define HG_ATTR_ABI_IMPORT __declspec(dllimport)
#define HG_ATTR_ABI_EXPORT __declspec(dllexport)
#define HG_ATTR_ABI_HIDDEN
#elif __has_attribute(__visibility__)
#define HG_ATTR_ABI_IMPORT __attribute__((__visibility__("default")))
#define HG_ATTR_ABI_EXPORT __attribute__((__visibility__("default")))
#define HG_ATTR_ABI_HIDDEN __attribute__((__visibility__("hidden")))
#else
#define HG_ATTR_ABI_IMPORT
#define HG_ATTR_ABI_EXPORT
#define HG_ATTR_ABI_HIDDEN
#endif
#endif
