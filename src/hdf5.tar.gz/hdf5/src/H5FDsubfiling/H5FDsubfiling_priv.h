// (c) The HDF Group
#ifndef H5FDsubfiling_priv_H
#define H5FDsubfiling_priv_H
#include <stdatomic.h>
#include "H5private.h"
#include "H5CXprivate.h"
#include "H5Dprivate.h"
#include "H5Eprivate.h"
#include "H5FDsubfiling.h"
#include "H5FDioc.h"
#include "H5Iprivate.h"
#include "H5MMprivate.h"
#include "H5Pprivate.h"
#include "H5subfiling_common.h"
#define DRIVER_INFO_MESSAGE_MAX_INFO   65536
#define DRIVER_INFO_MESSAGE_MAX_LENGTH 65552
typedef struct _info_header {
    uint8_t version;
    uint8_t unused_1;
    uint8_t unused_2;
    uint8_t unused_3;
    int32_t info_length;
    char    vfd_key[8];
} info_header_t;
#ifdef __cplusplus
extern "C" {
#endif
H5_DLL herr_t H5FD__subfiling__truncate_sub_files(hid_t context_id, int64_t logical_file_eof, MPI_Comm comm);
H5_DLL herr_t H5FD__subfiling__get_real_eof(hid_t context_id, int64_t *logical_eof_ptr);
#ifdef __cplusplus
}
#endif
#endif
