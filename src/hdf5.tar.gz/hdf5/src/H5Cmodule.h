// (c) The HDF Group
#ifndef H5Cmodule_H
#define H5Cmodule_H
#define H5C_MODULE
#define H5_MY_PKG     H5C
#define H5_MY_PKG_ERR H5E_CACHE
#endif
