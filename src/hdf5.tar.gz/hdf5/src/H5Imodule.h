// (c) The HDF Group
#ifndef H5Imodule_H
#define H5Imodule_H
#define H5I_MODULE
#define H5_MY_PKG     H5I
#define H5_MY_PKG_ERR H5E_ID
#endif
