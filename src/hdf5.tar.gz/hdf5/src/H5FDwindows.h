// (c) The HDF Group
#ifndef H5FDwindows_H
#define H5FDwindows_H
#define H5FD_WINDOWS (H5FD_sec2_init())
#ifdef __cplusplus
extern "C" {
#endif
H5_DLL herr_t H5Pset_fapl_windows(hid_t fapl_id);
#ifdef __cplusplus
}
#endif
#endif
