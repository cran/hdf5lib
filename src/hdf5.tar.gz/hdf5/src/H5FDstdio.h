// (c) The HDF Group
#ifndef H5FDstdio_H
#define H5FDstdio_H
#include "H5Ipublic.h"
#define H5FD_STDIO (H5FDperform_init(H5FD_stdio_init))
#ifdef __cplusplus
extern "C" {
#endif
H5_DLL hid_t H5FD_stdio_init(void);
H5_DLL herr_t H5Pset_fapl_stdio(hid_t fapl_id);
#ifdef __cplusplus
}
#endif
#endif
