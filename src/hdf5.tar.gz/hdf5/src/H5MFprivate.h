// (c) The HDF Group
#ifndef H5MFprivate_H
#define H5MFprivate_H
#include "H5Fprivate.h"
#include "H5FDprivate.h"
H5_DLL herr_t H5MF_init_merge_flags(H5F_shared_t *f_sh);
H5_DLL herr_t H5MF_get_freespace(H5F_t *f, hsize_t *tot_space, hsize_t *meta_size);
H5_DLL herr_t H5MF_close(H5F_t *f);
H5_DLL herr_t H5MF_try_close(H5F_t *f);
H5_DLL haddr_t H5MF_alloc(H5F_t *f, H5FD_mem_t type, hsize_t size);
H5_DLL haddr_t H5MF_aggr_vfd_alloc(H5F_t *f, H5FD_mem_t type, hsize_t size);
H5_DLL herr_t  H5MF_xfree(H5F_t *f, H5FD_mem_t type, haddr_t addr, hsize_t size);
H5_DLL herr_t H5MF_try_extend(H5F_t *f, H5FD_mem_t type, haddr_t addr, hsize_t size, hsize_t extra_requested);
H5_DLL htri_t H5MF_try_shrink(H5F_t *f, H5FD_mem_t alloc_type, haddr_t addr, hsize_t size);
H5_DLL herr_t H5MF_get_free_sections(H5F_t *f, H5FD_mem_t type, size_t nsects, H5F_sect_info_t *sect_info,
                                     size_t *sect_count);
H5_DLL haddr_t H5MF_alloc_tmp(H5F_t *f, hsize_t size);
H5_DLL herr_t H5MF_free_aggrs(H5F_t *f);
H5_DLL herr_t H5MF_settle_raw_data_fsm(H5F_t *f, bool *fsm_settled);
H5_DLL herr_t H5MF_settle_meta_data_fsm(H5F_t *f, bool *fsm_settled);
H5_DLL herr_t H5MF_tidy_self_referential_fsm_hack(H5F_t *f);
#ifdef H5MF_DEBUGGING
H5_DLL herr_t H5MF_sects_debug(H5F_t *f, haddr_t addr, FILE *stream, int indent, int fwidth);
#endif
#endif
