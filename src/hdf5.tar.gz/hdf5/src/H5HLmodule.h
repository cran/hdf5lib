// (c) The HDF Group
#ifndef H5HLmodule_H
#define H5HLmodule_H
#define H5HL_MODULE
#define H5_MY_PKG     H5HL
#define H5_MY_PKG_ERR H5E_HEAP
#endif
