// (c) The HDF Group
#if !(defined H5M_FRIEND || defined H5M_MODULE)
#error "Do not include this file outside the H5M package!"
#endif
#ifndef H5Mpkg_H
#define H5Mpkg_H
#include "H5Mprivate.h"
#endif
