// (c) The HDF Group
#ifndef H5SLmodule_H
#define H5SLmodule_H
#define H5SL_MODULE
#define H5_MY_PKG     H5SL
#define H5_MY_PKG_ERR H5E_SLIST
#endif
