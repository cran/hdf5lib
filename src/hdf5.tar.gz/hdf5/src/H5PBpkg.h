// (c) The HDF Group
#if !(defined H5PB_FRIEND || defined H5PB_MODULE)
#error "Do not include this file outside the H5PB package!"
#endif
#ifndef H5PBpkg_H
#define H5PBpkg_H
#include "H5PBprivate.h"
typedef struct H5PB_entry_t {
    void          *page_buf_ptr;
    haddr_t        addr;
    H5F_mem_page_t type;
    bool           is_dirty;
    struct H5PB_entry_t *next;
    struct H5PB_entry_t *prev;
} H5PB_entry_t;
#endif
