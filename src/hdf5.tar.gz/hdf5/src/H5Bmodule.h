// (c) The HDF Group
#ifndef H5Bmodule_H
#define H5Bmodule_H
#define H5B_MODULE
#define H5_MY_PKG     H5B
#define H5_MY_PKG_ERR H5E_BTREE
#endif
