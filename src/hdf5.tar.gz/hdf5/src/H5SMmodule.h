// (c) The HDF Group
#ifndef H5SMmodule_H
#define H5SMmodule_H
#define H5SM_MODULE
#define H5_MY_PKG     H5SM
#define H5_MY_PKG_ERR H5E_SOHM
#endif
