// (c) The HDF Group
#ifndef H5HGmodule_H
#define H5HGmodule_H
#define H5HG_MODULE
#define H5_MY_PKG     H5HG
#define H5_MY_PKG_ERR H5E_HEAP
#endif
