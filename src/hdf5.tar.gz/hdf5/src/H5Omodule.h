// (c) The HDF Group
#ifndef H5Omodule_H
#define H5Omodule_H
#define H5O_MODULE
#define H5_MY_PKG     H5O
#define H5_MY_PKG_ERR H5E_OHDR
#endif
