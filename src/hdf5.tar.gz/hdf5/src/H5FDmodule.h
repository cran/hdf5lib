// (c) The HDF Group
#ifndef H5FDmodule_H
#define H5FDmodule_H
#define H5FD_MODULE
#define H5_MY_PKG     H5FD
#define H5_MY_PKG_ERR H5E_VFL
#endif
