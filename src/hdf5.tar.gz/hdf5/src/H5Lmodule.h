// (c) The HDF Group
#ifndef H5Lmodule_H
#define H5Lmodule_H
#define H5L_MODULE
#define H5_MY_PKG     H5L
#define H5_MY_PKG_ERR H5E_LINK
#endif
