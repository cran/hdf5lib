// (c) The HDF Group
#ifndef H5HFmodule_H
#define H5HFmodule_H
#define H5HF_MODULE
#define H5_MY_PKG     H5HF
#define H5_MY_PKG_ERR H5E_HEAP
#endif
