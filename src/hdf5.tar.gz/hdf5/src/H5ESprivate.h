// (c) The HDF Group
#ifndef H5ESprivate_H
#define H5ESprivate_H
#include "H5ESpublic.h"
#include "H5ESdevelop.h"
#include "H5VLprivate.h"
typedef struct H5ES_t H5ES_t;
herr_t H5ES_insert(hid_t es_id, H5VL_t *connector, void *token, const char *caller, const char *caller_args,
                   ...);
H5_DLL herr_t H5ES_init(void);
#endif
