// (c) The HDF Group
#ifndef H5CXmodule_H
#define H5CXmodule_H
#define H5CX_MODULE
#define H5_MY_PKG     H5CX
#define H5_MY_PKG_ERR H5E_CONTEXT
#endif
