// (c) The HDF Group
#ifndef H5Mprivate_H
#define H5Mprivate_H
#include "H5Mpublic.h"
#include "H5Oprivate.h"
#include "H5Sprivate.h"
#include "H5Zprivate.h"
#ifdef NDEBUG
#undef H5M_DEBUG
#endif
#define H5M_ACS_KEY_PREFETCH_SIZE_NAME                                                                       \
    "key_prefetch_size"
#define H5M_ACS_KEY_ALLOC_SIZE_NAME                                                                          \
    "key_alloc_size"
#define H5D_TEMP_BUF_SIZE (1024 * 1024)
#define H5D_IO_VECTOR_SIZE 1024
#define H5D_VLEN_ALLOC      NULL
#define H5D_VLEN_ALLOC_INFO NULL
#define H5D_VLEN_FREE       NULL
#define H5D_VLEN_FREE_INFO  NULL
#define H5D_VIRTUAL_DEF_LIST_SIZE 8
H5_DLL herr_t H5M_init(void);
#endif
