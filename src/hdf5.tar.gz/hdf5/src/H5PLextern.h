// (c) The HDF Group
#ifndef H5PLextern_H
#define H5PLextern_H
#include "hdf5.h"
#if defined(_MSC_VER)
#define H5PLUGIN_DLL __declspec(dllexport)
#elif (__GNUC__ >= 4)
#define H5PLUGIN_DLL __attribute__((visibility("default")))
#else
#define H5PLUGIN_DLL
#endif
#ifdef __cplusplus
extern "C" {
#endif
H5PLUGIN_DLL H5PL_type_t H5PLget_plugin_type(void);
H5PLUGIN_DLL const void *H5PLget_plugin_info(void);
#ifdef __cplusplus
}
#endif
#endif
