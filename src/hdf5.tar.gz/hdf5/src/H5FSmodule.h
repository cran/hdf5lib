// (c) The HDF Group
#ifndef H5FSmodule_H
#define H5FSmodule_H
#define H5FS_MODULE
#define H5_MY_PKG     H5FS
#define H5_MY_PKG_ERR H5E_FSPACE
#endif
