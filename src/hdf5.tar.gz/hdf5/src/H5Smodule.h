// (c) The HDF Group
#ifndef H5Smodule_H
#define H5Smodule_H
#define H5S_MODULE
#define H5_MY_PKG     H5S
#define H5_MY_PKG_ERR H5E_DATASPACE
#endif
