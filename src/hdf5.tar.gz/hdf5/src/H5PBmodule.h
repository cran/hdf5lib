// (c) The HDF Group
#ifndef H5PBmodule_H
#define H5PBmodule_H
#define H5PB_MODULE
#define H5_MY_PKG     H5PB
#define H5_MY_PKG_ERR H5E_RESOURCE
#endif
