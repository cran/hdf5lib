// (c) The HDF Group
#if !(defined H5ES_FRIEND || defined H5ES_MODULE)
#error "Do not include this file outside the H5ES package!"
#endif
#ifndef H5ESpkg_H
#define H5ESpkg_H
#include "H5ESprivate.h"
typedef struct H5ES_event_t {
    H5VL_object_t       *request;
    struct H5ES_event_t *prev, *next;
    H5ES_op_info_t op_info;
} H5ES_event_t;
typedef struct H5ES_event_list_t {
    size_t        count;
    H5ES_event_t *head, *tail;
} H5ES_event_list_t;
struct H5ES_t {
    uint64_t                   op_counter;
    H5ES_event_insert_func_t   ins_func;
    void                      *ins_ctx;
    H5ES_event_complete_func_t comp_func;
    void                      *comp_ctx;
    H5ES_event_list_t active;
    bool              err_occurred;
    H5ES_event_list_t failed;
};
typedef int (*H5ES_list_iter_func_t)(H5ES_event_t *ev, void *ctx);
H5_DLL H5ES_t *H5ES__create(void) H5_ATTR_MALLOC;
H5_DLL herr_t  H5ES__insert_request(H5ES_t *es, H5VL_t *connector, void *token);
H5_DLL herr_t  H5ES__wait(H5ES_t *es, uint64_t timeout, size_t *num_in_progress, bool *op_failed);
H5_DLL herr_t  H5ES__get_requests(H5ES_t *es, H5_iter_order_t order, hid_t *connector_ids, void **requests,
                                  size_t array_len);
H5_DLL herr_t  H5ES__cancel(H5ES_t *es, size_t *num_not_canceled, bool *op_failed);
H5_DLL herr_t  H5ES__get_err_info(H5ES_t *es, size_t num_err_info, H5ES_err_info_t err_info[],
                                  size_t *num_cleared);
H5_DLL void   H5ES__list_append(H5ES_event_list_t *el, H5ES_event_t *ev);
H5_DLL size_t H5ES__list_count(const H5ES_event_list_t *el);
H5_DLL int    H5ES__list_iterate(H5ES_event_list_t *el, H5_iter_order_t order, H5ES_list_iter_func_t cb,
                                 void *ctx);
H5_DLL void   H5ES__list_remove(H5ES_event_list_t *el, const H5ES_event_t *ev);
H5_DLL H5ES_event_t *H5ES__event_new(H5VL_t *connector, void *token);
H5_DLL herr_t        H5ES__event_free(H5ES_event_t *ev);
H5_DLL herr_t        H5ES__event_completed(H5ES_event_t *ev, H5ES_event_list_t *el);
#endif
