// (c) The HDF Group
#ifndef H5FDfamily_H
#define H5FDfamily_H
#define H5FD_FAMILY (H5FDperform_init(H5FD_family_init))
#define H5FD_FAMILY_VALUE H5_VFD_FAMILY
#ifdef __cplusplus
extern "C" {
#endif
H5_DLL hid_t H5FD_family_init(void);
H5_DLL herr_t H5Pset_fapl_family(hid_t fapl_id, hsize_t memb_size, hid_t memb_fapl_id);
H5_DLL herr_t H5Pget_fapl_family(hid_t fapl_id, hsize_t *memb_size, hid_t *memb_fapl_id);
#ifdef __cplusplus
}
#endif
#endif
