// (c) The HDF Group
#ifndef H5FDonion_header_H
#define H5FDonion_header_H
#define H5FD_ONION_ENCODED_SIZE_HEADER 40
#define H5FD_ONION_HEADER_FLAG_WRITE_LOCK     0x1
#define H5FD_ONION_HEADER_FLAG_PAGE_ALIGNMENT 0x2
#define H5FD_ONION_HEADER_SIGNATURE           "OHDH"
#define H5FD_ONION_HEADER_VERSION_CURR        1
typedef struct H5FD_onion_header_t {
    uint8_t  version;
    uint32_t flags;
    uint32_t page_size;
    uint64_t origin_eof;
    uint64_t history_addr;
    uint64_t history_size;
    uint32_t checksum;
} H5FD_onion_header_t;
#ifdef __cplusplus
extern "C" {
#endif
H5_DLL herr_t H5FD__onion_ingest_header(H5FD_onion_header_t *hdr_out, H5FD_t *raw_file, haddr_t addr);
H5_DLL herr_t H5FD__onion_write_header(H5FD_onion_header_t *header, H5FD_t *file);
H5_DLL size_t H5FD__onion_header_decode(unsigned char *buf, H5FD_onion_header_t *header);
H5_DLL size_t H5FD__onion_header_encode(H5FD_onion_header_t *header, unsigned char *buf, uint32_t *checksum);
#ifdef __cplusplus
}
#endif
#endif
