// (c) The HDF Group
#ifndef H5ACmodule_H
#define H5ACmodule_H
#define H5AC_MODULE
#define H5_MY_PKG     H5AC
#define H5_MY_PKG_ERR H5E_CACHE
#endif
