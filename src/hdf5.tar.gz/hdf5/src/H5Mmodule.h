// (c) The HDF Group
#ifndef H5Mmodule_H
#define H5Mmodule_H
#define H5M_MODULE
#define H5_MY_PKG     H5M
#define H5_MY_PKG_ERR H5E_MAP
#endif
