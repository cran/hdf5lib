// (c) The HDF Group
#ifndef H5Gmodule_H
#define H5Gmodule_H
#define H5G_MODULE
#define H5_MY_PKG     H5G
#define H5_MY_PKG_ERR H5E_SYM
#endif
