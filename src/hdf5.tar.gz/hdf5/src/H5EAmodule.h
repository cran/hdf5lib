// (c) The HDF Group
#ifndef H5EAmodule_H
#define H5EAmodule_H
#define H5EA_MODULE
#define H5_MY_PKG     H5EA
#define H5_MY_PKG_ERR H5E_EARRAY
#endif
