// (c) The HDF Group
#ifndef H5Fmodule_H
#define H5Fmodule_H
#define H5F_MODULE
#define H5_MY_PKG     H5F
#define H5_MY_PKG_ERR H5E_FILE
#endif
