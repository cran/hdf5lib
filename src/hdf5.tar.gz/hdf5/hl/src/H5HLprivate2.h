// (c) The HDF Group
#ifndef H5HLprivate2_H
#define H5HLprivate2_H
#include "hdf5.h"
#include "hdf5_hl.h"
#include "H5private.h"
#endif
