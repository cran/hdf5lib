// (c) The HDF Group
#ifndef H5IMprivate_H
#define H5IMprivate_H
#include "H5HLprivate2.h"
#include "H5IMpublic.h"
#define IMAGE_CLASS   "IMAGE"
#define PALETTE_CLASS "PALETTE"
#define IMAGE_VERSION "1.2"
#define IMAGE8_RANK   2
#define IMAGE24_RANK  3
H5_HLDLL herr_t H5IM_find_palette(hid_t loc_id);
#endif
