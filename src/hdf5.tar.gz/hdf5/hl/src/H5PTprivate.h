// (c) The HDF Group
#ifndef H5PTprivate_H
#define H5PTprivate_H
#include "H5HLprivate2.h"
#include "H5PTpublic.h"
#endif
