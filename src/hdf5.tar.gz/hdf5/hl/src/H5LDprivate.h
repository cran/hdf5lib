// (c) The HDF Group
#ifndef H5LDprivate_H
#define H5LDprivate_H
#include "H5HLprivate2.h"
#include "H5LDpublic.h"
typedef struct H5LD_memb_t {
    size_t tot_offset;
    size_t last_tsize;
    hid_t  last_tid;
    char **names;
} H5LD_memb_t;
#ifdef __cplusplus
extern "C" {
#endif
H5_HLDLL void H5LD_clean_vector(H5LD_memb_t *listv[]);
H5_HLDLL int  H5LD_construct_vector(char *fields, H5LD_memb_t *listv[], hid_t par_tid);
#ifdef __cplusplus
}
#endif
#endif
