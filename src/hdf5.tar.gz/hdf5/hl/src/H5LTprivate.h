// (c) The HDF Group
#ifndef H5LTprivate_H
#define H5LTprivate_H
#include "H5HLprivate2.h"
#include "H5LTpublic.h"
H5_HLDLL herr_t H5LT_get_attribute_disk(hid_t obj_id, const char *attr_name, void *data);
H5_HLDLL herr_t H5LT_set_attribute_numerical(hid_t loc_id, const char *obj_name, const char *attr_name,
                                             size_t size, hid_t type_id, const void *data);
H5_HLDLL herr_t H5LT_set_attribute_string(hid_t dset_id, const char *name, const char *buf);
H5_HLDLL char  *H5LT_dtype_to_text(hid_t dtype, char *dt_str, H5LT_lang_t lang, size_t *slen,
                                   bool no_user_buf);
H5_HLDLL hid_t  H5LTyyparse(void);
#endif
