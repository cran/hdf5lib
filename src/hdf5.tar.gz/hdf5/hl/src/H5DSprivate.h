/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the COPYING file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */
#ifndef H5DSprivate_H
#define H5DSprivate_H
#include "H5HLprivate2.h"
#include "H5DSpublic.h"
typedef struct ds_list_t {
    hobj_ref_t   ref;
    unsigned int dim_idx;
} ds_list_t;
typedef struct nds_list_t {
    H5R_ref_t    ref;
    unsigned int dim_idx;
} nds_list_t;
#endif
