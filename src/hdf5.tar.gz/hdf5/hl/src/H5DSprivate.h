// (c) The HDF Group
#ifndef H5DSprivate_H
#define H5DSprivate_H
#include "H5HLprivate2.h"
#include "H5DSpublic.h"
typedef struct ds_list_t {
    hobj_ref_t   ref;
    unsigned int dim_idx;
} ds_list_t;
typedef struct nds_list_t {
    H5R_ref_t    ref;
    unsigned int dim_idx;
} nds_list_t;
#endif
