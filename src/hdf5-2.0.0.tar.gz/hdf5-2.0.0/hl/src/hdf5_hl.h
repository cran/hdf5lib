/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef HDF5_HL_H
#define HDF5_HL_H

#include "hdf5.h"       
#include "H5DOpublic.h" 
#include "H5DSpublic.h" 
#include "H5LTpublic.h" 
#include "H5IMpublic.h" 
#include "H5TBpublic.h" 
#include "H5PTpublic.h" 
#include "H5LDpublic.h" 

#endif 
