/* A Bison parser, made by GNU Bison 3.8.2.  */

#ifndef YY_H5LTYY_HL_SRC_H5LTPARSE_H_INCLUDED
# define YY_H5LTYY_HL_SRC_H5LTPARSE_H_INCLUDED

#ifndef YYDEBUG
# define YYDEBUG 0
#endif
#if YYDEBUG
extern int H5LTyydebug;
#endif

#ifndef YYTOKENTYPE
# define YYTOKENTYPE
  enum yytokentype
  {
    YYEMPTY = -2,
    YYEOF = 0,                     
    YYerror = 256,                 
    YYUNDEF = 257,                 
    H5T_STD_I8BE_TOKEN = 258,      
    H5T_STD_I8LE_TOKEN = 259,      
    H5T_STD_I16BE_TOKEN = 260,     
    H5T_STD_I16LE_TOKEN = 261,     
    H5T_STD_I32BE_TOKEN = 262,     
    H5T_STD_I32LE_TOKEN = 263,     
    H5T_STD_I64BE_TOKEN = 264,     
    H5T_STD_I64LE_TOKEN = 265,     
    H5T_STD_U8BE_TOKEN = 266,      
    H5T_STD_U8LE_TOKEN = 267,      
    H5T_STD_U16BE_TOKEN = 268,     
    H5T_STD_U16LE_TOKEN = 269,     
    H5T_STD_U32BE_TOKEN = 270,     
    H5T_STD_U32LE_TOKEN = 271,     
    H5T_STD_U64BE_TOKEN = 272,     
    H5T_STD_U64LE_TOKEN = 273,     
    H5T_NATIVE_CHAR_TOKEN = 274,   
    H5T_NATIVE_SCHAR_TOKEN = 275,  
    H5T_NATIVE_UCHAR_TOKEN = 276,  
    H5T_NATIVE_SHORT_TOKEN = 277,  
    H5T_NATIVE_USHORT_TOKEN = 278, 
    H5T_NATIVE_INT_TOKEN = 279,    
    H5T_NATIVE_UINT_TOKEN = 280,   
    H5T_NATIVE_LONG_TOKEN = 281,   
    H5T_NATIVE_ULONG_TOKEN = 282,  
    H5T_NATIVE_LLONG_TOKEN = 283,  
    H5T_NATIVE_ULLONG_TOKEN = 284, 
    H5T_IEEE_F16BE_TOKEN = 285,    
    H5T_IEEE_F16LE_TOKEN = 286,    
    H5T_IEEE_F32BE_TOKEN = 287,    
    H5T_IEEE_F32LE_TOKEN = 288,    
    H5T_IEEE_F64BE_TOKEN = 289,    
    H5T_IEEE_F64LE_TOKEN = 290,    
    H5T_FLOAT_BFLOAT16BE_TOKEN = 291, 
    H5T_FLOAT_BFLOAT16LE_TOKEN = 292, 
    H5T_FLOAT_F8E4M3_TOKEN = 293,  
    H5T_FLOAT_F8E5M2_TOKEN = 294,  
    H5T_NATIVE_FLOAT16_TOKEN = 295, 
    H5T_NATIVE_FLOAT_TOKEN = 296,  
    H5T_NATIVE_DOUBLE_TOKEN = 297, 
    H5T_NATIVE_LDOUBLE_TOKEN = 298, 
    H5T_COMPLEX_IEEE_F16BE_TOKEN = 299, 
    H5T_COMPLEX_IEEE_F16LE_TOKEN = 300, 
    H5T_COMPLEX_IEEE_F32BE_TOKEN = 301, 
    H5T_COMPLEX_IEEE_F32LE_TOKEN = 302, 
    H5T_COMPLEX_IEEE_F64BE_TOKEN = 303, 
    H5T_COMPLEX_IEEE_F64LE_TOKEN = 304, 
    H5T_NATIVE_FLOAT_COMPLEX_TOKEN = 305, 
    H5T_NATIVE_DOUBLE_COMPLEX_TOKEN = 306, 
    H5T_NATIVE_LDOUBLE_COMPLEX_TOKEN = 307, 
    H5T_STRING_TOKEN = 308,        
    STRSIZE_TOKEN = 309,           
    STRPAD_TOKEN = 310,            
    CSET_TOKEN = 311,              
    CTYPE_TOKEN = 312,             
    H5T_VARIABLE_TOKEN = 313,      
    H5T_STR_NULLTERM_TOKEN = 314,  
    H5T_STR_NULLPAD_TOKEN = 315,   
    H5T_STR_SPACEPAD_TOKEN = 316,  
    H5T_CSET_ASCII_TOKEN = 317,    
    H5T_CSET_UTF8_TOKEN = 318,     
    H5T_C_S1_TOKEN = 319,          
    H5T_FORTRAN_S1_TOKEN = 320,    
    H5T_OPAQUE_TOKEN = 321,        
    OPQ_SIZE_TOKEN = 322,          
    OPQ_TAG_TOKEN = 323,           
    H5T_COMPOUND_TOKEN = 324,      
    H5T_ENUM_TOKEN = 325,          
    H5T_ARRAY_TOKEN = 326,         
    H5T_VLEN_TOKEN = 327,          
    H5T_COMPLEX_TOKEN = 328,       
    STRING = 329,                  
    NUMBER = 330                   
  };
  typedef enum yytokentype yytoken_kind_t;
#endif

#if ! defined YYSTYPE && ! defined YYSTYPE_IS_DECLARED
union YYSTYPE
{
#line 68 "hl/src//H5LTparse.y"

    int     ival;         
    char    *sval;        
    hid_t   hid;          

#line 145 "hl/src//H5LTparse.h"

};
typedef union YYSTYPE YYSTYPE;
# define YYSTYPE_IS_TRIVIAL 1
# define YYSTYPE_IS_DECLARED 1
#endif

extern YYSTYPE H5LTyylval;

hid_t H5LTyyparse (void);

#endif 
