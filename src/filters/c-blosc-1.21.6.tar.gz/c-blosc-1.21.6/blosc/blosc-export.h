/*********************************************************************
  Blosc - Blocked Shuffling and Compression Library

  Author: Francesc Alted <francesc@blosc.org>

  See LICENSE.txt for details about copyright and rights to use.
**********************************************************************/
#ifndef BLOSC_EXPORT_H
#define BLOSC_EXPORT_H

#define BLOSC_EXPORT
#define BLOSC_NO_EXPORT

#endif
