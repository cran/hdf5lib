/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef H5LTprivate_H
#define H5LTprivate_H

#include "H5HLprivate2.h"

#include "H5LTpublic.h"

H5HL_DLL herr_t H5LT_get_attribute_disk(hid_t obj_id, const char *attr_name, void *data);
H5HL_DLL herr_t H5LT_set_attribute_numerical(hid_t loc_id, const char *obj_name, const char *attr_name,
                                             size_t size, hid_t type_id, const void *data);
H5HL_DLL herr_t H5LT_set_attribute_string(hid_t dset_id, const char *name, const char *buf);
H5HL_DLL char  *H5LT_dtype_to_text(hid_t dtype, char *dt_str, H5LT_lang_t lang, size_t *slen,
                                   bool no_user_buf);
H5HL_DLL hid_t  H5LTyyparse(void);

#endif
