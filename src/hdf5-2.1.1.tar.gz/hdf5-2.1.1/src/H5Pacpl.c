/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include "H5Pmodule.h" 

#include "H5private.h"  
#include "H5Eprivate.h" 
#include "H5Ppkg.h"     

const H5P_libclass_t H5P_CLS_ACRT[1] = {{
    "attribute create",        
    H5P_TYPE_ATTRIBUTE_CREATE, 

    &H5P_CLS_STRING_CREATE_g,       
    &H5P_CLS_ATTRIBUTE_CREATE_g,    
    &H5P_CLS_ATTRIBUTE_CREATE_ID_g, 
    &H5P_LST_ATTRIBUTE_CREATE_ID_g, 
    NULL,                           

    NULL, 
    NULL, 
    NULL, 
    NULL, 
    NULL, 
    NULL  
}};

