/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#ifndef H5Ppublic_H
#define H5Ppublic_H

#include "H5public.h"   
#include "H5ACpublic.h" 
#include "H5Dpublic.h"  
#include "H5Fpublic.h"  
#include "H5FDpublic.h" 
#include "H5Ipublic.h"  
#include "H5Lpublic.h"  
#include "H5MMpublic.h" 
#include "H5Opublic.h"  
#include "H5Spublic.h"  
#include "H5Tpublic.h"  
#include "H5Zpublic.h"  

#define H5P_ROOT (H5OPEN H5P_CLS_ROOT_ID_g)

#define H5P_OBJECT_CREATE (H5OPEN H5P_CLS_OBJECT_CREATE_ID_g)

#define H5P_FILE_CREATE (H5OPEN H5P_CLS_FILE_CREATE_ID_g)

#define H5P_FILE_ACCESS (H5OPEN H5P_CLS_FILE_ACCESS_ID_g)

#define H5P_DATASET_CREATE (H5OPEN H5P_CLS_DATASET_CREATE_ID_g)

#define H5P_DATASET_ACCESS (H5OPEN H5P_CLS_DATASET_ACCESS_ID_g)

#define H5P_DATASET_XFER (H5OPEN H5P_CLS_DATASET_XFER_ID_g)

#define H5P_FILE_MOUNT (H5OPEN H5P_CLS_FILE_MOUNT_ID_g)

#define H5P_GROUP_CREATE (H5OPEN H5P_CLS_GROUP_CREATE_ID_g)

#define H5P_GROUP_ACCESS (H5OPEN H5P_CLS_GROUP_ACCESS_ID_g)

#define H5P_DATATYPE_CREATE (H5OPEN H5P_CLS_DATATYPE_CREATE_ID_g)

#define H5P_DATATYPE_ACCESS (H5OPEN H5P_CLS_DATATYPE_ACCESS_ID_g)

#define H5P_MAP_CREATE (H5OPEN H5P_CLS_MAP_CREATE_ID_g)

#define H5P_MAP_ACCESS (H5OPEN H5P_CLS_MAP_ACCESS_ID_g)

#define H5P_STRING_CREATE (H5OPEN H5P_CLS_STRING_CREATE_ID_g)

#define H5P_ATTRIBUTE_CREATE (H5OPEN H5P_CLS_ATTRIBUTE_CREATE_ID_g)

#define H5P_ATTRIBUTE_ACCESS (H5OPEN H5P_CLS_ATTRIBUTE_ACCESS_ID_g)

#define H5P_OBJECT_COPY (H5OPEN H5P_CLS_OBJECT_COPY_ID_g)

#define H5P_LINK_CREATE (H5OPEN H5P_CLS_LINK_CREATE_ID_g)

#define H5P_LINK_ACCESS (H5OPEN H5P_CLS_LINK_ACCESS_ID_g)

#define H5P_VOL_INITIALIZE (H5OPEN H5P_CLS_VOL_INITIALIZE_ID_g)

#define H5P_REFERENCE_ACCESS (H5OPEN H5P_CLS_REFERENCE_ACCESS_ID_g)

#define H5P_FILE_CREATE_DEFAULT (H5OPEN H5P_LST_FILE_CREATE_ID_g)

#define H5P_FILE_ACCESS_DEFAULT (H5OPEN H5P_LST_FILE_ACCESS_ID_g)

#define H5P_DATASET_CREATE_DEFAULT (H5OPEN H5P_LST_DATASET_CREATE_ID_g)

#define H5P_DATASET_ACCESS_DEFAULT (H5OPEN H5P_LST_DATASET_ACCESS_ID_g)

#define H5P_DATASET_XFER_DEFAULT (H5OPEN H5P_LST_DATASET_XFER_ID_g)

#define H5P_FILE_MOUNT_DEFAULT (H5OPEN H5P_LST_FILE_MOUNT_ID_g)

#define H5P_GROUP_CREATE_DEFAULT (H5OPEN H5P_LST_GROUP_CREATE_ID_g)

#define H5P_GROUP_ACCESS_DEFAULT (H5OPEN H5P_LST_GROUP_ACCESS_ID_g)

#define H5P_DATATYPE_CREATE_DEFAULT (H5OPEN H5P_LST_DATATYPE_CREATE_ID_g)

#define H5P_DATATYPE_ACCESS_DEFAULT (H5OPEN H5P_LST_DATATYPE_ACCESS_ID_g)

#define H5P_MAP_CREATE_DEFAULT (H5OPEN H5P_LST_MAP_CREATE_ID_g)

#define H5P_MAP_ACCESS_DEFAULT (H5OPEN H5P_LST_MAP_ACCESS_ID_g)

#define H5P_ATTRIBUTE_CREATE_DEFAULT (H5OPEN H5P_LST_ATTRIBUTE_CREATE_ID_g)

#define H5P_ATTRIBUTE_ACCESS_DEFAULT (H5OPEN H5P_LST_ATTRIBUTE_ACCESS_ID_g)

#define H5P_OBJECT_COPY_DEFAULT (H5OPEN H5P_LST_OBJECT_COPY_ID_g)

#define H5P_LINK_CREATE_DEFAULT (H5OPEN H5P_LST_LINK_CREATE_ID_g)

#define H5P_LINK_ACCESS_DEFAULT (H5OPEN H5P_LST_LINK_ACCESS_ID_g)

#define H5P_VOL_INITIALIZE_DEFAULT (H5OPEN H5P_LST_VOL_INITIALIZE_ID_g)

#define H5P_REFERENCE_ACCESS_DEFAULT (H5OPEN H5P_LST_REFERENCE_ACCESS_ID_g)

#define H5P_CRT_ORDER_TRACKED 0x0001

#define H5P_CRT_ORDER_INDEXED 0x0002

#define H5P_DEFAULT 0 

#ifdef __cplusplus
extern "C" {
#endif

//! <!-- [H5P_cls_create_func_t_snip] -->

typedef herr_t (*H5P_cls_create_func_t)(hid_t prop_id, void *create_data);
//! <!-- [H5P_cls_create_func_t_snip] -->

//! <!-- [H5P_cls_copy_func_t_snip] -->

typedef herr_t (*H5P_cls_copy_func_t)(hid_t new_prop_id, hid_t old_prop_id, void *copy_data);
//! <!-- [H5P_cls_copy_func_t_snip] -->

//! <!-- [H5P_cls_close_func_t_snip] -->

typedef herr_t (*H5P_cls_close_func_t)(hid_t prop_id, void *close_data);
//! <!-- [H5P_cls_close_func_t_snip] -->

//! <!-- [H5P_prp_cb1_t_snip] -->

typedef herr_t (*H5P_prp_cb1_t)(const char *name, size_t size, void *value);
//! <!-- [H5P_prp_cb1_t_snip] -->

//! <!-- [H5P_prp_cb2_t_snip] -->

typedef herr_t (*H5P_prp_cb2_t)(hid_t prop_id, const char *name, size_t size, void *value);
//! <!-- [H5P_prp_cb2_t_snip] -->

typedef H5P_prp_cb1_t H5P_prp_create_func_t;
typedef H5P_prp_cb2_t H5P_prp_set_func_t;
typedef H5P_prp_cb2_t H5P_prp_get_func_t;
//! <!-- [H5P_prp_encode_func_t_snip] -->

typedef herr_t (*H5P_prp_encode_func_t)(const void *value, void **buf, size_t *size);
//! <!-- [H5P_prp_encode_func_t_snip] -->
//! <!-- [H5P_prp_decode_func_t_snip] -->

typedef herr_t (*H5P_prp_decode_func_t)(const void **buf, void *value);
//! <!-- [H5P_prp_decode_func_t_snip] -->
typedef H5P_prp_cb2_t H5P_prp_delete_func_t;
typedef H5P_prp_cb1_t H5P_prp_copy_func_t;

//! <!-- [H5P_prp_compare_func_t_snip] -->

typedef int (*H5P_prp_compare_func_t)(const void *value1, const void *value2, size_t size);
//! <!-- [H5P_prp_compare_func_t_snip] -->

typedef H5P_prp_cb1_t H5P_prp_close_func_t;

//! <!-- [H5P_iterate_t_snip] -->

typedef herr_t (*H5P_iterate_t)(hid_t id, const char *name, void *iter_data);
//! <!-- [H5P_iterate_t_snip] -->

//! <!--[H5D_mpio_actual_chunk_opt_mode_t_snip] -->

typedef enum H5D_mpio_actual_chunk_opt_mode_t {
    H5D_MPIO_NO_CHUNK_OPTIMIZATION = 0,
    
    H5D_MPIO_LINK_CHUNK,
    
    H5D_MPIO_MULTI_CHUNK
    
} H5D_mpio_actual_chunk_opt_mode_t;
//! <!--[H5D_mpio_actual_chunk_opt_mode_t_snip] -->

//! <!-- [H5D_mpio_actual_io_mode_t_snip] -->

typedef enum H5D_mpio_actual_io_mode_t {
    H5D_MPIO_NO_COLLECTIVE = 0x0,
    
    H5D_MPIO_CHUNK_INDEPENDENT = 0x1,
    
    H5D_MPIO_CHUNK_COLLECTIVE = 0x2,
    
    H5D_MPIO_CHUNK_MIXED = 0x1 | 0x2,
    
    H5D_MPIO_CONTIGUOUS_COLLECTIVE = 0x4
    
} H5D_mpio_actual_io_mode_t;
//! <!-- [H5D_mpio_actual_io_mode_t_snip] -->

//! <!-- [H5D_mpio_no_collective_cause_t_snip] -->

typedef enum H5D_mpio_no_collective_cause_t {
    H5D_MPIO_COLLECTIVE = 0x00,
    
    H5D_MPIO_SET_INDEPENDENT = 0x01,
    
    H5D_MPIO_DATATYPE_CONVERSION = 0x02,
    
    H5D_MPIO_DATA_TRANSFORMS = 0x04,
    
    H5D_MPIO_MPI_OPT_TYPES_ENV_VAR_DISABLED = 0x08,
    
    H5D_MPIO_NOT_SIMPLE_OR_SCALAR_DATASPACES = 0x10,
    
    H5D_MPIO_NOT_CONTIGUOUS_OR_CHUNKED_DATASET = 0x20,
    
    H5D_MPIO_PARALLEL_FILTERED_WRITES_DISABLED = 0x40,
    
    H5D_MPIO_ERROR_WHILE_CHECKING_COLLECTIVE_POSSIBLE = 0x80,
    
    H5D_MPIO_NO_SELECTION_IO = 0x100,
    
    H5D_MPIO_NO_COLLECTIVE_MAX_CAUSE = 0x200
    
} H5D_mpio_no_collective_cause_t;
//! <!-- [H5D_mpio_no_collective_cause_t_snip] -->

#define H5D_SEL_IO_DISABLE_BY_API (0x0001u)

#define H5D_SEL_IO_NOT_CONTIGUOUS_OR_CHUNKED_DATASET (0x0002u)

#define H5D_SEL_IO_CONTIGUOUS_SIEVE_BUFFER (0x0004u)

#define H5D_SEL_IO_NO_VECTOR_OR_SELECTION_IO_CB (0x0008u)

#define H5D_SEL_IO_PAGE_BUFFER (0x0010u)

#define H5D_SEL_IO_DATASET_FILTER (0x0020u)

#define H5D_SEL_IO_CHUNK_CACHE (0x0040u)

#define H5D_SEL_IO_TCONV_BUF_TOO_SMALL (0x0080u)

#define H5D_SEL_IO_BKG_BUF_TOO_SMALL (0x0100u)

#define H5D_SEL_IO_DEFAULT_OFF (0x0200u)

#define H5D_MPIO_NO_SELECTION_IO_CAUSES                                                                      \
    (H5D_SEL_IO_DISABLE_BY_API | H5D_SEL_IO_TCONV_BUF_TOO_SMALL | H5D_SEL_IO_BKG_BUF_TOO_SMALL |             \
     H5D_SEL_IO_DATASET_FILTER | H5D_SEL_IO_CHUNK_CACHE)

//! <!--[H5D_selection_io_mode_t_snip] -->

typedef enum H5D_selection_io_mode_t {
    H5D_SELECTION_IO_MODE_DEFAULT = 0,
    
    H5D_SELECTION_IO_MODE_OFF,
    
    H5D_SELECTION_IO_MODE_ON
    
} H5D_selection_io_mode_t;
//! <!--[H5D_selection_io_mode_t_snip] -->

#define H5D_SCALAR_IO    (0x0001u) 
#define H5D_VECTOR_IO    (0x0002u) 
#define H5D_SELECTION_IO (0x0004u) 

H5_DLLVAR hid_t H5P_CLS_ROOT_ID_g;
H5_DLLVAR hid_t H5P_CLS_OBJECT_CREATE_ID_g;
H5_DLLVAR hid_t H5P_CLS_FILE_CREATE_ID_g;
H5_DLLVAR hid_t H5P_CLS_FILE_ACCESS_ID_g;
H5_DLLVAR hid_t H5P_CLS_DATASET_CREATE_ID_g;
H5_DLLVAR hid_t H5P_CLS_DATASET_ACCESS_ID_g;
H5_DLLVAR hid_t H5P_CLS_DATASET_XFER_ID_g;
H5_DLLVAR hid_t H5P_CLS_FILE_MOUNT_ID_g;
H5_DLLVAR hid_t H5P_CLS_GROUP_CREATE_ID_g;
H5_DLLVAR hid_t H5P_CLS_GROUP_ACCESS_ID_g;
H5_DLLVAR hid_t H5P_CLS_DATATYPE_CREATE_ID_g;
H5_DLLVAR hid_t H5P_CLS_DATATYPE_ACCESS_ID_g;
H5_DLLVAR hid_t H5P_CLS_MAP_CREATE_ID_g;
H5_DLLVAR hid_t H5P_CLS_MAP_ACCESS_ID_g;
H5_DLLVAR hid_t H5P_CLS_STRING_CREATE_ID_g;
H5_DLLVAR hid_t H5P_CLS_ATTRIBUTE_CREATE_ID_g;
H5_DLLVAR hid_t H5P_CLS_ATTRIBUTE_ACCESS_ID_g;
H5_DLLVAR hid_t H5P_CLS_OBJECT_COPY_ID_g;
H5_DLLVAR hid_t H5P_CLS_LINK_CREATE_ID_g;
H5_DLLVAR hid_t H5P_CLS_LINK_ACCESS_ID_g;
H5_DLLVAR hid_t H5P_CLS_VOL_INITIALIZE_ID_g;
H5_DLLVAR hid_t H5P_CLS_REFERENCE_ACCESS_ID_g;

H5_DLLVAR hid_t H5P_LST_FILE_CREATE_ID_g;
H5_DLLVAR hid_t H5P_LST_FILE_ACCESS_ID_g;
H5_DLLVAR hid_t H5P_LST_DATASET_CREATE_ID_g;
H5_DLLVAR hid_t H5P_LST_DATASET_ACCESS_ID_g;
H5_DLLVAR hid_t H5P_LST_DATASET_XFER_ID_g;
H5_DLLVAR hid_t H5P_LST_FILE_MOUNT_ID_g;
H5_DLLVAR hid_t H5P_LST_GROUP_CREATE_ID_g;
H5_DLLVAR hid_t H5P_LST_GROUP_ACCESS_ID_g;
H5_DLLVAR hid_t H5P_LST_DATATYPE_CREATE_ID_g;
H5_DLLVAR hid_t H5P_LST_DATATYPE_ACCESS_ID_g;
H5_DLLVAR hid_t H5P_LST_MAP_CREATE_ID_g;
H5_DLLVAR hid_t H5P_LST_MAP_ACCESS_ID_g;
H5_DLLVAR hid_t H5P_LST_ATTRIBUTE_CREATE_ID_g;
H5_DLLVAR hid_t H5P_LST_ATTRIBUTE_ACCESS_ID_g;
H5_DLLVAR hid_t H5P_LST_OBJECT_COPY_ID_g;
H5_DLLVAR hid_t H5P_LST_LINK_CREATE_ID_g;
H5_DLLVAR hid_t H5P_LST_LINK_ACCESS_ID_g;
H5_DLLVAR hid_t H5P_LST_VOL_INITIALIZE_ID_g;
H5_DLLVAR hid_t H5P_LST_REFERENCE_ACCESS_ID_g;

H5_DLL herr_t H5Pclose(hid_t plist_id);

H5_DLL herr_t H5Pclose_class(hid_t plist_id);

H5_DLL hid_t H5Pcopy(hid_t plist_id);

H5_DLL herr_t H5Pcopy_prop(hid_t dst_id, hid_t src_id, const char *name);

H5_DLL hid_t H5Pcreate(hid_t cls_id);

H5_DLL hid_t H5Pcreate_class(hid_t parent, const char *name, H5P_cls_create_func_t create, void *create_data,
                             H5P_cls_copy_func_t copy, void *copy_data, H5P_cls_close_func_t close,
                             void *close_data);

H5_DLL hid_t H5Pdecode(const void *buf);

H5_DLL herr_t H5Pencode2(hid_t plist_id, void *buf, size_t *nalloc, hid_t fapl_id);

H5_DLL htri_t H5Pequal(hid_t id1, hid_t id2);

H5_DLL htri_t H5Pexist(hid_t plist_id, const char *name);

H5_DLL herr_t H5Pget(hid_t plist_id, const char *name, void *value);

H5_DLL hid_t H5Pget_class(hid_t plist_id);

H5_DLL char *H5Pget_class_name(hid_t pclass_id);

H5_DLL hid_t H5Pget_class_parent(hid_t pclass_id);

H5_DLL herr_t H5Pget_nprops(hid_t id, size_t *nprops);

H5_DLL herr_t H5Pget_size(hid_t id, const char *name, size_t *size);

H5_DLL herr_t H5Pinsert2(hid_t plist_id, const char *name, size_t size, void *value, H5P_prp_set_func_t set,
                         H5P_prp_get_func_t get, H5P_prp_delete_func_t prp_del, H5P_prp_copy_func_t copy,
                         H5P_prp_compare_func_t compare, H5P_prp_close_func_t close);

H5_DLL htri_t H5Pisa_class(hid_t plist_id, hid_t pclass_id);

H5_DLL int H5Piterate(hid_t id, int *idx, H5P_iterate_t iter_func, void *iter_data);

H5_DLL herr_t H5Pregister2(hid_t cls_id, const char *name, size_t size, void *def_value,
                           H5P_prp_create_func_t create, H5P_prp_set_func_t set, H5P_prp_get_func_t get,
                           H5P_prp_delete_func_t prp_del, H5P_prp_copy_func_t copy,
                           H5P_prp_compare_func_t compare, H5P_prp_close_func_t close);

H5_DLL herr_t H5Premove(hid_t plist_id, const char *name);

H5_DLL herr_t H5Pset(hid_t plist_id, const char *name, const void *value);

H5_DLL herr_t H5Punregister(hid_t pclass_id, const char *name);

H5_DLL htri_t H5Pall_filters_avail(hid_t plist_id);

H5_DLL herr_t H5Pget_attr_creation_order(hid_t plist_id, unsigned *crt_order_flags);

H5_DLL herr_t H5Pget_attr_phase_change(hid_t plist_id, unsigned *max_compact, unsigned *min_dense);

H5_DLL H5Z_filter_t H5Pget_filter2(hid_t plist_id, unsigned idx, unsigned int *flags ,
                                   size_t *cd_nelmts , unsigned cd_values[] , size_t namelen,
                                   char name[], unsigned *filter_config );

H5_DLL herr_t H5Pget_filter_by_id2(hid_t plist_id, H5Z_filter_t filter_id, unsigned int *flags ,
                                   size_t *cd_nelmts , unsigned cd_values[] , size_t namelen,
                                   char name[] , unsigned *filter_config );

H5_DLL int H5Pget_nfilters(hid_t plist_id);

H5_DLL herr_t H5Pget_obj_track_times(hid_t plist_id, bool *track_times);

H5_DLL herr_t H5Pmodify_filter(hid_t plist_id, H5Z_filter_t filter, unsigned int flags, size_t cd_nelmts,
                               const unsigned int cd_values[]);

H5_DLL herr_t H5Premove_filter(hid_t plist_id, H5Z_filter_t filter);

H5_DLL herr_t H5Pset_attr_creation_order(hid_t plist_id, unsigned crt_order_flags);

H5_DLL herr_t H5Pset_attr_phase_change(hid_t plist_id, unsigned max_compact, unsigned min_dense);

H5_DLL herr_t H5Pset_deflate(hid_t plist_id, unsigned level);

H5_DLL herr_t H5Pset_filter(hid_t plist_id, H5Z_filter_t filter, unsigned int flags, size_t cd_nelmts,
                            const unsigned int cd_values[]);

H5_DLL herr_t H5Pset_fletcher32(hid_t plist_id);

H5_DLL herr_t H5Pset_obj_track_times(hid_t plist_id, bool track_times);

H5_DLL herr_t H5Pget_file_space_page_size(hid_t plist_id, hsize_t *fsp_size);

H5_DLL herr_t H5Pget_file_space_strategy(hid_t plist_id, H5F_fspace_strategy_t *strategy, bool *persist,
                                         hsize_t *threshold);

H5_DLL herr_t H5Pget_istore_k(hid_t plist_id, unsigned *ik );

H5_DLL herr_t H5Pget_shared_mesg_index(hid_t plist_id, unsigned index_num, unsigned *mesg_type_flags,
                                       unsigned *min_mesg_size);

H5_DLL herr_t H5Pget_shared_mesg_nindexes(hid_t plist_id, unsigned *nindexes);

H5_DLL herr_t H5Pget_shared_mesg_phase_change(hid_t plist_id, unsigned *max_list, unsigned *min_btree);

H5_DLL herr_t H5Pget_sizes(hid_t plist_id, size_t *sizeof_addr , size_t *sizeof_size );

H5_DLL herr_t H5Pget_sym_k(hid_t plist_id, unsigned *ik , unsigned *lk );

H5_DLL herr_t H5Pget_userblock(hid_t plist_id, hsize_t *size);

H5_DLL herr_t H5Pset_file_space_page_size(hid_t plist_id, hsize_t fsp_size);

H5_DLL herr_t H5Pset_file_space_strategy(hid_t plist_id, H5F_fspace_strategy_t strategy, bool persist,
                                         hsize_t threshold);

H5_DLL herr_t H5Pset_istore_k(hid_t plist_id, unsigned ik);

H5_DLL herr_t H5Pset_shared_mesg_index(hid_t plist_id, unsigned index_num, unsigned mesg_type_flags,
                                       unsigned min_mesg_size);

H5_DLL herr_t H5Pset_shared_mesg_nindexes(hid_t plist_id, unsigned nindexes);

H5_DLL herr_t H5Pset_shared_mesg_phase_change(hid_t plist_id, unsigned max_list, unsigned min_btree);

H5_DLL herr_t H5Pset_sizes(hid_t plist_id, size_t sizeof_addr, size_t sizeof_size);

H5_DLL herr_t H5Pset_sym_k(hid_t plist_id, unsigned ik, unsigned lk);

H5_DLL herr_t H5Pset_userblock(hid_t plist_id, hsize_t size);

H5_DLL herr_t H5Pget_alignment(hid_t fapl_id, hsize_t *threshold , hsize_t *alignment );

H5_DLL herr_t H5Pget_cache(hid_t plist_id, int *mdc_nelmts, 
                           size_t *rdcc_nslots , size_t *rdcc_nbytes , double *rdcc_w0);

H5_DLL herr_t H5Pget_core_write_tracking(hid_t fapl_id, bool *is_enabled, size_t *page_size);

H5_DLL hid_t H5Pget_driver(hid_t plist_id);

H5_DLL const void *H5Pget_driver_info(hid_t plist_id);

H5_DLL ssize_t H5Pget_driver_config_str(hid_t fapl_id, char *config_buf, size_t buf_size);

H5_DLL herr_t H5Pget_elink_file_cache_size(hid_t plist_id, unsigned *efc_size);

H5_DLL herr_t H5Pget_evict_on_close(hid_t fapl_id, bool *evict_on_close);

H5_DLL herr_t H5Pget_family_offset(hid_t fapl_id, hsize_t *offset);

H5_DLL herr_t H5Pget_fclose_degree(hid_t fapl_id, H5F_close_degree_t *degree);

H5_DLL herr_t H5Pget_file_image(hid_t fapl_id, void **buf_ptr_ptr, size_t *buf_len_ptr);

H5_DLL herr_t H5Pget_file_image_callbacks(hid_t fapl_id, H5FD_file_image_callbacks_t *callbacks_ptr);

H5_DLL herr_t H5Pget_file_locking(hid_t fapl_id, bool *use_file_locking, bool *ignore_when_disabled);

H5_DLL herr_t H5Pget_gc_references(hid_t fapl_id, unsigned *gc_ref );

H5_DLL herr_t H5Pget_libver_bounds(hid_t plist_id, H5F_libver_t *low, H5F_libver_t *high);

H5_DLL herr_t H5Pget_mdc_config(hid_t plist_id, H5AC_cache_config_t *config_ptr); 

H5_DLL herr_t H5Pget_mdc_image_config(hid_t plist_id, H5AC_cache_image_config_t *config_ptr );

H5_DLL herr_t H5Pget_mdc_log_options(hid_t plist_id, bool *is_enabled, char *location, size_t *location_size,
                                     bool *start_on_access);

H5_DLL herr_t H5Pget_meta_block_size(hid_t fapl_id, hsize_t *size);

H5_DLL herr_t H5Pget_metadata_read_attempts(hid_t plist_id, unsigned *attempts);

H5_DLL herr_t H5Pget_multi_type(hid_t fapl_id, H5FD_mem_t *type);

H5_DLL herr_t H5Pget_object_flush_cb(hid_t plist_id, H5F_flush_cb_t *func, void **udata);

H5_DLL herr_t H5Pget_page_buffer_size(hid_t plist_id, size_t *buf_size, unsigned *min_meta_perc,
                                      unsigned *min_raw_perc);

H5_DLL herr_t H5Pget_sieve_buf_size(hid_t fapl_id, size_t *size );

H5_DLL herr_t H5Pget_small_data_block_size(hid_t fapl_id, hsize_t *size );

H5_DLL herr_t H5Pget_vol_id(hid_t plist_id, hid_t *vol_id);

H5_DLL herr_t H5Pget_vol_info(hid_t plist_id, void **vol_info);

H5_DLL herr_t H5Pset_alignment(hid_t fapl_id, hsize_t threshold, hsize_t alignment);

H5_DLL herr_t H5Pset_cache(hid_t plist_id, int mdc_nelmts, size_t rdcc_nslots, size_t rdcc_nbytes,
                           double rdcc_w0);

H5_DLL herr_t H5Pset_core_write_tracking(hid_t fapl_id, bool is_enabled, size_t page_size);

H5_DLL herr_t H5Pset_driver(hid_t plist_id, hid_t driver_id, const void *driver_info);

H5_DLL herr_t H5Pset_driver_by_name(hid_t plist_id, const char *driver_name, const char *driver_config);

H5_DLL herr_t H5Pset_driver_by_value(hid_t plist_id, H5FD_class_value_t driver_value,
                                     const char *driver_config);

H5_DLL herr_t H5Pset_elink_file_cache_size(hid_t plist_id, unsigned efc_size);

H5_DLL herr_t H5Pset_evict_on_close(hid_t fapl_id, bool evict_on_close);

H5_DLL herr_t H5Pset_family_offset(hid_t fapl_id, hsize_t offset);

H5_DLL herr_t H5Pset_fclose_degree(hid_t fapl_id, H5F_close_degree_t degree);

H5_DLL herr_t H5Pset_file_image(hid_t fapl_id, void *buf_ptr, size_t buf_len);

H5_DLL herr_t H5Pset_file_image_callbacks(hid_t fapl_id, H5FD_file_image_callbacks_t *callbacks_ptr);

H5_DLL herr_t H5Pset_file_locking(hid_t fapl_id, bool use_file_locking, bool ignore_when_disabled);

H5_DLL herr_t H5Pset_gc_references(hid_t fapl_id, unsigned gc_ref);

H5_DLL herr_t H5Pset_libver_bounds(hid_t plist_id, H5F_libver_t low, H5F_libver_t high);

H5_DLL herr_t H5Pset_mdc_config(hid_t plist_id, H5AC_cache_config_t *config_ptr);

H5_DLL herr_t H5Pset_mdc_log_options(hid_t plist_id, bool is_enabled, const char *location,
                                     bool start_on_access);

H5_DLL herr_t H5Pset_meta_block_size(hid_t fapl_id, hsize_t size);

H5_DLL herr_t H5Pset_metadata_read_attempts(hid_t plist_id, unsigned attempts);

H5_DLL herr_t H5Pset_multi_type(hid_t fapl_id, H5FD_mem_t type);

H5_DLL herr_t H5Pset_object_flush_cb(hid_t plist_id, H5F_flush_cb_t func, void *udata);

H5_DLL herr_t H5Pset_sieve_buf_size(hid_t fapl_id, size_t size);

H5_DLL herr_t H5Pset_small_data_block_size(hid_t fapl_id, hsize_t size);

H5_DLL herr_t H5Pset_vol(hid_t plist_id, hid_t new_vol_id, const void *new_vol_info);

H5_DLL herr_t H5Pget_vol_cap_flags(hid_t plist_id, uint64_t *cap_flags);

#ifdef H5_HAVE_PARALLEL

H5_DLL herr_t H5Pset_all_coll_metadata_ops(hid_t plist_id, bool is_collective);

H5_DLL herr_t H5Pget_all_coll_metadata_ops(hid_t plist_id, bool *is_collective);

H5_DLL herr_t H5Pset_coll_metadata_write(hid_t plist_id, bool is_collective);

H5_DLL herr_t H5Pget_coll_metadata_write(hid_t plist_id, bool *is_collective);

H5_DLL herr_t H5Pget_mpi_params(hid_t fapl_id, MPI_Comm *comm, MPI_Info *info);

H5_DLL herr_t H5Pset_mpi_params(hid_t fapl_id, MPI_Comm comm, MPI_Info info);
#endif 

H5_DLL herr_t H5Pset_mdc_image_config(hid_t plist_id, H5AC_cache_image_config_t *config_ptr);

H5_DLL herr_t H5Pset_page_buffer_size(hid_t plist_id, size_t buf_size, unsigned min_meta_per,
                                      unsigned min_raw_per);

H5_DLL herr_t H5Pset_relax_file_integrity_checks(hid_t plist_id, uint64_t flags);

H5_DLL herr_t H5Pget_relax_file_integrity_checks(hid_t plist_id, uint64_t *flags);

H5_DLL herr_t H5Pfill_value_defined(hid_t plist, H5D_fill_value_t *status);

H5_DLL herr_t H5Pget_alloc_time(hid_t plist_id, H5D_alloc_time_t *alloc_time );

H5_DLL int H5Pget_chunk(hid_t plist_id, int max_ndims, hsize_t dim[] );

H5_DLL herr_t H5Pget_chunk_opts(hid_t plist_id, unsigned *opts);

H5_DLL herr_t H5Pget_dset_no_attrs_hint(hid_t dcpl_id, bool *minimize);

H5_DLL herr_t H5Pget_virtual_spatial_tree(hid_t dcpl_id, bool *use_tree);

H5_DLL herr_t H5Pget_external(hid_t plist_id, unsigned idx, size_t name_size, char *name ,
                              HDoff_t *offset , hsize_t *size );

H5_DLL int H5Pget_external_count(hid_t plist_id);

H5_DLL herr_t H5Pget_fill_time(hid_t plist_id, H5D_fill_time_t *fill_time );

H5_DLL herr_t H5Pget_fill_value(hid_t plist_id, hid_t type_id, void *value );

H5_DLL H5D_layout_t H5Pget_layout(hid_t plist_id);

H5_DLL herr_t H5Pget_virtual_count(hid_t dcpl_id, size_t *count );

H5_DLL ssize_t H5Pget_virtual_dsetname(hid_t dcpl_id, size_t index, char *name , size_t size);

H5_DLL ssize_t H5Pget_virtual_filename(hid_t dcpl_id, size_t index, char *name , size_t size);

H5_DLL hid_t H5Pget_virtual_srcspace(hid_t dcpl_id, size_t index);

H5_DLL hid_t H5Pget_virtual_vspace(hid_t dcpl_id, size_t index);

H5_DLL herr_t H5Pset_alloc_time(hid_t plist_id, H5D_alloc_time_t alloc_time);

H5_DLL herr_t H5Pset_chunk(hid_t plist_id, int ndims, const hsize_t dim[]);

H5_DLL herr_t H5Pset_chunk_opts(hid_t plist_id, unsigned opts);

H5_DLL herr_t H5Pset_dset_no_attrs_hint(hid_t dcpl_id, bool minimize);

H5_DLL herr_t H5Pset_virtual_spatial_tree(hid_t dcpl_id, bool use_tree);

H5_DLL herr_t H5Pset_external(hid_t plist_id, const char *name, HDoff_t offset, hsize_t size);

H5_DLL herr_t H5Pset_fill_time(hid_t plist_id, H5D_fill_time_t fill_time);

H5_DLL herr_t H5Pset_fill_value(hid_t plist_id, hid_t type_id, const void *value);

H5_DLL herr_t H5Pset_shuffle(hid_t plist_id);

H5_DLL herr_t H5Pset_layout(hid_t plist_id, H5D_layout_t layout);

H5_DLL herr_t H5Pset_nbit(hid_t plist_id);

H5_DLL herr_t H5Pset_scaleoffset(hid_t plist_id, H5Z_SO_scale_type_t scale_type, int scale_factor);

H5_DLL herr_t H5Pset_szip(hid_t plist_id, unsigned options_mask, unsigned pixels_per_block);

H5_DLL herr_t H5Pset_virtual(hid_t dcpl_id, hid_t vspace_id, const char *src_file_name,
                             const char *src_dset_name, hid_t src_space_id);

H5_DLL herr_t H5Pget_append_flush(hid_t dapl_id, unsigned dims, hsize_t boundary[], H5D_append_cb_t *func,
                                  void **udata);

H5_DLL herr_t H5Pget_chunk_cache(hid_t dapl_id, size_t *rdcc_nslots , size_t *rdcc_nbytes ,
                                 double *rdcc_w0 );

H5_DLL ssize_t H5Pget_efile_prefix(hid_t dapl_id, char *prefix , size_t size);

H5_DLL ssize_t H5Pget_virtual_prefix(hid_t dapl_id, char *prefix , size_t size);

H5_DLL herr_t H5Pget_virtual_printf_gap(hid_t dapl_id, hsize_t *gap_size);

H5_DLL herr_t H5Pget_virtual_view(hid_t dapl_id, H5D_vds_view_t *view);

H5_DLL herr_t H5Pset_append_flush(hid_t dapl_id, unsigned ndims, const hsize_t boundary[],
                                  H5D_append_cb_t func, void *udata);

H5_DLL herr_t H5Pset_chunk_cache(hid_t dapl_id, size_t rdcc_nslots, size_t rdcc_nbytes, double rdcc_w0);

H5_DLL herr_t H5Pset_efile_prefix(hid_t dapl_id, const char *prefix);

H5_DLL herr_t H5Pset_virtual_prefix(hid_t dapl_id, const char *prefix);

H5_DLL herr_t H5Pset_virtual_printf_gap(hid_t dapl_id, hsize_t gap_size);

H5_DLL herr_t H5Pset_virtual_view(hid_t dapl_id, H5D_vds_view_t view);

H5_DLL herr_t H5Pget_btree_ratios(hid_t plist_id, double *left , double *middle ,
                                  double *right );

H5_DLL size_t H5Pget_buffer(hid_t plist_id, void **tconv , void **bkg );

H5_DLL ssize_t H5Pget_data_transform(hid_t plist_id, char *expression , size_t size);

H5_DLL H5Z_EDC_t H5Pget_edc_check(hid_t plist_id);

H5_DLL herr_t H5Pget_hyper_vector_size(hid_t fapl_id, size_t *size );

H5_DLL int H5Pget_preserve(hid_t plist_id);

H5_DLL herr_t H5Pget_type_conv_cb(hid_t dxpl_id, H5T_conv_except_func_t *op, void **operate_data);

H5_DLL herr_t H5Pget_vlen_mem_manager(hid_t plist_id, H5MM_allocate_t *alloc_func, void **alloc_info,
                                      H5MM_free_t *free_func, void **free_info);

H5_DLL herr_t H5Pset_btree_ratios(hid_t plist_id, double left, double middle, double right);

H5_DLL herr_t H5Pset_buffer(hid_t plist_id, size_t size, void *tconv, void *bkg);

H5_DLL herr_t H5Pset_data_transform(hid_t plist_id, const char *expression);

H5_DLL herr_t H5Pset_edc_check(hid_t plist_id, H5Z_EDC_t check);

H5_DLL herr_t H5Pset_filter_callback(hid_t plist_id, H5Z_filter_func_t func, void *op_data);

H5_DLL herr_t H5Pset_hyper_vector_size(hid_t plist_id, size_t size);

H5_DLL herr_t H5Pset_preserve(hid_t plist_id, bool status);

H5_DLL herr_t H5Pset_type_conv_cb(hid_t dxpl_id, H5T_conv_except_func_t op, void *operate_data);

H5_DLL herr_t H5Pset_vlen_mem_manager(hid_t plist_id, H5MM_allocate_t alloc_func, void *alloc_info,
                                      H5MM_free_t free_func, void *free_info);

#ifdef H5_HAVE_PARALLEL

H5_DLL herr_t H5Pget_mpio_actual_chunk_opt_mode(hid_t                             plist_id,
                                                H5D_mpio_actual_chunk_opt_mode_t *actual_chunk_opt_mode);

H5_DLL herr_t H5Pget_mpio_actual_io_mode(hid_t plist_id, H5D_mpio_actual_io_mode_t *actual_io_mode);

H5_DLL herr_t H5Pget_mpio_no_collective_cause(hid_t plist_id, uint32_t *local_no_collective_cause,
                                              uint32_t *global_no_collective_cause);
#endif 

H5_DLL herr_t H5Pset_dataset_io_hyperslab_selection(hid_t plist_id, unsigned rank, H5S_seloper_t op,
                                                    const hsize_t start[], const hsize_t stride[],
                                                    const hsize_t count[], const hsize_t block[]);

H5_DLL herr_t H5Pset_selection_io(hid_t plist_id, H5D_selection_io_mode_t selection_io_mode);

H5_DLL herr_t H5Pget_selection_io(hid_t plist_id, H5D_selection_io_mode_t *selection_io_mode);

H5_DLL herr_t H5Pget_no_selection_io_cause(hid_t plist_id, uint32_t *no_selection_io_cause);

H5_DLL herr_t H5Pget_actual_selection_io_mode(hid_t plist_id, uint32_t *actual_selection_io_mode);

H5_DLL herr_t H5Pset_modify_write_buf(hid_t plist_id, bool modify_write_buf);

H5_DLL herr_t H5Pget_modify_write_buf(hid_t plist_id, bool *modify_write_buf);

H5_DLL herr_t H5Pget_create_intermediate_group(hid_t plist_id, unsigned *crt_intmd );

H5_DLL herr_t H5Pset_create_intermediate_group(hid_t plist_id, unsigned crt_intmd);

H5_DLL herr_t H5Pget_est_link_info(hid_t plist_id, unsigned *est_num_entries ,
                                   unsigned *est_name_len );

H5_DLL herr_t H5Pget_link_creation_order(hid_t plist_id, unsigned *crt_order_flags );

H5_DLL herr_t H5Pget_link_phase_change(hid_t plist_id, unsigned *max_compact ,
                                       unsigned *min_dense );

H5_DLL herr_t H5Pget_local_heap_size_hint(hid_t plist_id, size_t *size_hint );

H5_DLL herr_t H5Pset_est_link_info(hid_t plist_id, unsigned est_num_entries, unsigned est_name_len);

H5_DLL herr_t H5Pset_link_creation_order(hid_t plist_id, unsigned crt_order_flags);

H5_DLL herr_t H5Pset_link_phase_change(hid_t plist_id, unsigned max_compact, unsigned min_dense);

H5_DLL herr_t H5Pset_local_heap_size_hint(hid_t plist_id, size_t size_hint);

#ifdef H5_HAVE_MAP_API

H5_DLL herr_t H5Pset_map_iterate_hints(hid_t mapl_id, size_t key_prefetch_size, size_t key_alloc_size);

H5_DLL herr_t H5Pget_map_iterate_hints(hid_t mapl_id, size_t *key_prefetch_size ,
                                       size_t *key_alloc_size );
#endif 

H5_DLL herr_t H5Pget_char_encoding(hid_t plist_id, H5T_cset_t *encoding );

H5_DLL herr_t H5Pset_char_encoding(hid_t plist_id, H5T_cset_t encoding);

H5_DLL herr_t H5Pget_elink_acc_flags(hid_t lapl_id, unsigned *flags);

H5_DLL herr_t H5Pget_elink_cb(hid_t lapl_id, H5L_elink_traverse_t *func, void **op_data);

H5_DLL hid_t H5Pget_elink_fapl(hid_t lapl_id);

H5_DLL ssize_t H5Pget_elink_prefix(hid_t plist_id, char *prefix, size_t size);

H5_DLL herr_t H5Pget_nlinks(hid_t plist_id, size_t *nlinks);

H5_DLL herr_t H5Pset_elink_acc_flags(hid_t lapl_id, unsigned flags);

H5_DLL herr_t H5Pset_elink_cb(hid_t lapl_id, H5L_elink_traverse_t func, void *op_data);

H5_DLL herr_t H5Pset_elink_fapl(hid_t lapl_id, hid_t fapl_id);

H5_DLL herr_t H5Pset_elink_prefix(hid_t plist_id, const char *prefix);

H5_DLL herr_t H5Pset_nlinks(hid_t plist_id, size_t nlinks);

H5_DLL herr_t H5Padd_merge_committed_dtype_path(hid_t plist_id, const char *path);

H5_DLL herr_t H5Pfree_merge_committed_dtype_paths(hid_t plist_id);

H5_DLL herr_t H5Pget_copy_object(hid_t plist_id, unsigned *copy_options );

H5_DLL herr_t H5Pget_mcdt_search_cb(hid_t plist_id, H5O_mcdt_search_cb_t *func, void **op_data);

H5_DLL herr_t H5Pset_copy_object(hid_t plist_id, unsigned copy_options);

H5_DLL herr_t H5Pset_mcdt_search_cb(hid_t plist_id, H5O_mcdt_search_cb_t func, void *op_data);

#ifndef H5_NO_DEPRECATED_SYMBOLS

#define H5P_NO_CLASS H5P_ROOT

H5_DLL herr_t H5Pregister1(hid_t cls_id, const char *name, size_t size, void *def_value,
                           H5P_prp_create_func_t prp_create, H5P_prp_set_func_t prp_set,
                           H5P_prp_get_func_t prp_get, H5P_prp_delete_func_t prp_del,
                           H5P_prp_copy_func_t prp_copy, H5P_prp_close_func_t prp_close);

H5_DLL herr_t H5Pinsert1(hid_t plist_id, const char *name, size_t size, void *value,
                         H5P_prp_set_func_t prp_set, H5P_prp_get_func_t prp_get,
                         H5P_prp_delete_func_t prp_delete, H5P_prp_copy_func_t prp_copy,
                         H5P_prp_close_func_t prp_close);

H5_DLL herr_t H5Pencode1(hid_t plist_id, void *buf, size_t *nalloc);

H5_DLL H5Z_filter_t H5Pget_filter1(hid_t plist_id, unsigned filter, unsigned int *flags ,
                                   size_t *cd_nelmts , unsigned cd_values[] , size_t namelen,
                                   char name[]);

H5_DLL herr_t H5Pget_filter_by_id1(hid_t plist_id, H5Z_filter_t id, unsigned int *flags ,
                                   size_t *cd_nelmts , unsigned cd_values[] , size_t namelen,
                                   char name[] );

H5_DLL herr_t H5Pget_version(hid_t plist_id, unsigned *boot , unsigned *freelist ,
                             unsigned *stab , unsigned *shhdr );

H5_DLL herr_t H5Pset_file_space(hid_t plist_id, H5F_file_space_type_t strategy, hsize_t threshold);

H5_DLL herr_t H5Pget_file_space(hid_t plist_id, H5F_file_space_type_t *strategy, hsize_t *threshold);
#endif 

#ifdef __cplusplus
}
#endif
#endif 
