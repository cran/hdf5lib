/* * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * *
 * Copyright by The HDF Group.                                               *
 * All rights reserved.                                                      *
 *                                                                           *
 * This file is part of HDF5.  The full HDF5 copyright notice, including     *
 * terms governing use, modification, and redistribution, is contained in    *
 * the LICENSE file, which can be found at the root of the source code       *
 * distribution tree, or in https://www.hdfgroup.org/licenses.               *
 * If you do not have access to either file, you may request a copy from     *
 * help@hdfgroup.org.                                                        *
 * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * * */

#include "H5Smodule.h" 
#define H5S_TESTING    

#include "H5private.h"  
#include "H5Eprivate.h" 
#include "H5Iprivate.h" 
#include "H5Spkg.h"     

herr_t
H5S__get_rebuild_status_test(hid_t space_id, H5S_diminfo_valid_t *status1, H5S_diminfo_valid_t *status2)
{
    H5S_t *space;               
    herr_t ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    assert(status1);
    assert(status2);

    
    if (NULL == (space = (H5S_t *)H5I_object_verify(space_id, H5I_DATASPACE)))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a dataspace");

    *status1 = space->select.sel_info.hslab->diminfo_valid;

    
    if (*status1 == H5S_DIMINFO_VALID_NO)
        H5S__hyper_rebuild(space);

    *status2 = space->select.sel_info.hslab->diminfo_valid;

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

herr_t
H5S__get_diminfo_status_test(hid_t space_id, H5S_diminfo_valid_t *status)
{
    H5S_t *space;               
    herr_t ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    assert(status);

    
    if (NULL == (space = (H5S_t *)H5I_object_verify(space_id, H5I_DATASPACE)))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a dataspace");

    *status = space->select.sel_info.hslab->diminfo_valid;

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5S__check_spans_tail_ptr(const H5S_hyper_span_info_t *span_lst)
{
    H5S_hyper_span_t *cur_elem;
    H5S_hyper_span_t *actual_tail = NULL;
    htri_t            ret_value   = true; 

    FUNC_ENTER_PACKAGE

    assert(span_lst);

    cur_elem = span_lst->head;
    while (cur_elem) {
        actual_tail = cur_elem;

        
        if (NULL != cur_elem->down)
            if ((ret_value = H5S__check_spans_tail_ptr(cur_elem->down)) < 0)
                HGOTO_ERROR(H5E_DATASPACE, H5E_INCONSISTENTSTATE, FAIL,
                            "the selection has inconsistent tail pointers");

        cur_elem = cur_elem->next;
    } 
    if (actual_tail != span_lst->tail)
        HGOTO_ERROR(H5E_DATASPACE, H5E_INCONSISTENTSTATE, FAIL,
                    "the selection has inconsistent tail pointers");

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5S__check_points_tail_ptr(const H5S_pnt_list_t *pnt_lst)
{
    H5S_pnt_node_t *cur_elem;
    H5S_pnt_node_t *actual_tail = NULL;
    htri_t          ret_value   = true; 

    FUNC_ENTER_PACKAGE

    assert(pnt_lst);

    cur_elem = pnt_lst->head;
    while (cur_elem) {
        actual_tail = cur_elem;
        cur_elem    = cur_elem->next;
    } 
    if (actual_tail != pnt_lst->tail)
        HGOTO_ERROR(H5E_DATASPACE, H5E_INCONSISTENTSTATE, FAIL,
                    "the selection has inconsistent tail pointers");

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

static herr_t
H5S__check_internal_consistency(const H5S_t *space)
{
    hsize_t  low_bounds[H5S_MAX_RANK];
    hsize_t  high_bounds[H5S_MAX_RANK];
    unsigned u;
    herr_t   ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    
    assert(space);

    if (space->select.type->type == H5S_SEL_NONE)
        HGOTO_DONE(ret_value);

    
    for (u = 0; u < space->extent.rank; u++) {
        low_bounds[u]  = HSIZET_MAX;
        high_bounds[u] = 0;
    } 

    
    if (H5S_get_select_bounds(space, low_bounds, high_bounds) < 0)
        HGOTO_ERROR(H5E_DATASPACE, H5E_INCONSISTENTSTATE, FAIL, "the bound box could not be retrieved");

    if (space->select.type->type == H5S_SEL_HYPERSLABS) {
        H5S_hyper_sel_t *hslab = space->select.sel_info.hslab;

        if (space->select.sel_info.hslab->diminfo_valid == H5S_DIMINFO_VALID_YES) {
            for (u = 0; u < space->extent.rank; u++) {
                if ((hsize_t)((hssize_t)hslab->diminfo.low_bounds[u] + space->select.offset[u]) !=
                    low_bounds[u])
                    HGOTO_ERROR(H5E_DATASPACE, H5E_INCONSISTENTSTATE, FAIL,
                                "the lower bound box of the selection is inconsistent");
                if ((hsize_t)((hssize_t)hslab->diminfo.high_bounds[u] + space->select.offset[u]) !=
                    high_bounds[u])
                    HGOTO_ERROR(H5E_DATASPACE, H5E_INCONSISTENTSTATE, FAIL,
                                "the higher bound box of the selection is inconsistent");
            } 
        }     
        else {
            for (u = 0; u < space->extent.rank; u++) {
                if ((hsize_t)((hssize_t)hslab->span_lst->low_bounds[u] + space->select.offset[u]) !=
                    low_bounds[u])
                    HGOTO_ERROR(H5E_DATASPACE, H5E_INCONSISTENTSTATE, FAIL,
                                "the lower bound box of the selection is inconsistent");
                if ((hsize_t)((hssize_t)hslab->span_lst->high_bounds[u] + space->select.offset[u]) !=
                    high_bounds[u])
                    HGOTO_ERROR(H5E_DATASPACE, H5E_INCONSISTENTSTATE, FAIL,
                                "the higher bound box of the selection is inconsistent");
            } 
        }     

        
        if ((NULL != hslab) && (NULL != hslab->span_lst))
            if (H5S__check_spans_tail_ptr(hslab->span_lst) < 0)
                HGOTO_ERROR(H5E_DATASPACE, H5E_INCONSISTENTSTATE, FAIL,
                            "the selection has inconsistent tail pointers");
    } 
    else if (space->select.type->type == H5S_SEL_POINTS) {
        H5S_pnt_list_t *pnt_lst = space->select.sel_info.pnt_lst;

        if (NULL != pnt_lst)
            if (H5S__check_points_tail_ptr(pnt_lst) < 0)
                HGOTO_ERROR(H5E_DATASPACE, H5E_INCONSISTENTSTATE, FAIL,
                            "the selection has inconsistent tail pointers");
    } 

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

htri_t
H5S__internal_consistency_test(hid_t space_id)
{
    H5S_t *space;            
    htri_t ret_value = true; 

    FUNC_ENTER_PACKAGE

    
    if (NULL == (space = (H5S_t *)H5I_object_verify(space_id, H5I_DATASPACE)))
        HGOTO_ERROR(H5E_ARGS, H5E_BADTYPE, FAIL, "not a dataspace");

    
    if (FAIL == H5S__check_internal_consistency(space))
        HGOTO_ERROR(H5E_DATASPACE, H5E_INCONSISTENTSTATE, FAIL,
                    "The dataspace has inconsistent internal state");

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 

herr_t
H5S__verify_offsets(hid_t space_id, const hssize_t *offset)
{
    H5S_t *space;               
    herr_t ret_value = SUCCEED; 

    FUNC_ENTER_PACKAGE

    if (NULL == (space = (H5S_t *)H5I_object_verify(space_id, H5I_DATASPACE)))
        HGOTO_ERROR(H5E_DATASPACE, H5E_BADID, FAIL, "not a dataspace");
    if (space->extent.rank == 0 ||
        (H5S_GET_EXTENT_TYPE(space) == H5S_SCALAR || H5S_GET_EXTENT_TYPE(space) == H5S_NULL))
        HGOTO_ERROR(H5E_DATASPACE, H5E_UNSUPPORTED, FAIL, "can't set offset on scalar or null dataspace");

    
    if (0 != memcmp(space->select.offset, offset, sizeof(hssize_t) * space->extent.rank))
        HGOTO_ERROR(H5E_DATASPACE, H5E_BADVALUE, FAIL, "internal offsets don't match parameters");

done:
    FUNC_LEAVE_NOAPI(ret_value)
} 
